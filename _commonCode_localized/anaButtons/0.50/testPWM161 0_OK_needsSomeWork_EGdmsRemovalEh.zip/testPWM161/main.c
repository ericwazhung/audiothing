
//From adc/0.21/testPWM161

//From...
//This is nearly identical to anaButtons/0.50/test/
// but for the tiny861
// Notes are probably not all updated, and probably weren't in "test"...
// (and below is a prime example)



// Prints "Hello World" on boot to the RS-232 Transmitter, then echos
// anything received, therafter.
// Send the numbers 0-9 to this device via RS-232.
// On reception, the heart will blink the requested number of times.
// (0 puts it back into fading-mode)



#include _ANABUTTONS_HEADER_
#include _HEARTBEAT_HEADER_
#include _POLLED_UAT_HEADER_
#include <stdio.h> //necessary for sprintf_P...
						// See notes in the makefile re: AVR_MIN_PRINTF
#include <util/delay.h>

//For large things like this, I prefer to have them located globally (or
//static) in order to show them in the memory-usage when building...
char stringBuffer[80];


int main(void)
{

	init_heartBeat();

	tcnter_init();
	puat_init(0);

	// If you're *only* using the tcnter for puat, it's entirely safe to do
	// something like this... BUT, there are various things which may use
	// tcnter in the background without your realizing (puar, for instance)
	// So don't get in the habit of doing this unless you're really on top
	// of things.

	//(Also, should put this in a PSTR() rather than a RAM-based
	//character array...)
/*
	char hello[] = "Hello World\n\r";
	char* character = hello;

	setHeartRate(16);

	//Nothing can be received during this loop...
	while(*character != '\0')
	{
		puat_sendByte(0, *character);
		character++;
		while(puat_dataWaiting(0))
		{
			tcnter_update();
			puat_update(0);
			heartUpdate();
		}
	}
*/
	puat_sendStringBlocking_P(0, stringBuffer, 
										PSTR("\n\ranaButtons Values:\n\r"));

	setHeartRate(0);

//	adc_takeInput(0);
//	adc_init();
//	adc_select(0);

//	adc_startConversion();

	static dms4day_t startTime = 0;

	while(1)
	{
		tcnter_update();
		puat_update(0);

		
		heartUpdate();

		int32_t buttonTimeVal = anaButtons_getDebounced();

      if(buttonTimeVal >= 0)
      {
         //char stringBuffer[20];

         extern uint16_t anaB_minSamples;
         extern uint32_t anaB_measurementCount;

         sprintf_P(stringBuffer,
               PSTR("buttonTime=%"PRIi32
                    " sampleCount=%"PRIu16
                    " measurementCount=%"PRIu32"\n\r"),
                  buttonTimeVal, anaB_minSamples, anaB_measurementCount);
         puat_sendStringBlocking(0, stringBuffer);
      }


	}

	return 0;
}

