#ifndef __PINOUT_H__
#define __PINOUT_H__

//This should be moved to the makefile...
//#define HEARTBEAT       PB6       //(MISO)
//#define HEARTBEATPIN    PINB
//#define HEARTCONNECTION LED_TIED_HIGH


//Using the programming-header for debugging uart...
//
//
// 1  GND
// 2  V+
// 3  SCK   PB5   Rx0   (puar)
// 4  MOSI  PB4   Tx0   (puat)
// 5  /RST
// 6  MISO  PB6   (Heart)

#define Rx0pin    PB5      //SCK
#define Rx0PORT   PORTB

//Making it more pin-compatible with sdramThing3.0...
#define Tx0pin		PB4		//MOSI
#define Tx0PORT	PORTB



#endif

