// Prints "Hello World" on boot to the RS-232 Transmitter, then echos
// anything received, therafter.
// Send the numbers 0-9 to this device via RS-232.
// On reception, the heart will blink the requested number of times.
// (0 puts it back into fading-mode)



#include _ANABUTTONS_HEADER_
#include _HEARTBEAT_HEADER_
#if(!defined(PUAR_DISABLED) || !PUAR_DISABLED)
#include _POLLED_UAR_HEADER_
#endif
#include _POLLED_UAT_HEADER_
#include <stdio.h> //necessary for sprintf_P...
						// See notes in the makefile re: AVR_MIN_PRINTF


//For large things like this, I prefer to have them located globally (or
//static) in order to show them in the memory-usage when building...
char stringBuffer[80];


void main(void)
{

	init_heartBeat();

	tcnter_init();
#if(!defined(PUAR_DISABLED) || !PUAR_DISABLED)
	puar_init(0);
#endif
	puat_init(0);

	// If you're *only* using the tcnter for puat, it's entirely safe to do
	// something like this... BUT, there are various things which may use
	// tcnter in the background without your realizing (puar, for instance)
	// So don't get in the habit of doing this unless you're really on top
	// of things.

	//(Also, should put this in a PSTR() rather than a RAM-based
	//character array...)
/*
	char hello[] = "Hello World\n\r";
	char* character = hello;

	setHeartRate(16);

	//Nothing can be received during this loop...
	while(*character != '\0')
	{
		puat_sendByte(0, *character);
		character++;
		while(puat_dataWaiting(0))
		{
			tcnter_update();
			puat_update(0);
			heartUpdate();
		}
	}
*/
	puat_sendStringBlocking_P(0, stringBuffer, 
										PSTR("\n\rPress a button on the analog array"
	  											" to see its mesasured value.\n\r"));

	setHeartRate(0);

	while(1)
	{
		tcnter_update();
		puat_update(0);
#if(!defined(PUAR_DISABLED) || !PUAR_DISABLED)
		puar_update(0);
		if(puar_dataWaiting(0))
		{
			uint8_t byte = puar_getByte(0);

			if((byte >= '0') && (byte <= '9'))
				set_heartBlink(byte-'0');

			//Echo the received character...

			//The output buffer shouldn't be full, right?
			if(!puat_dataWaiting(0))
				puat_sendByte(0, byte);
			
		}
#endif

		heartUpdate();

		int32_t buttonTimeVal = anaButtons_getDebounced();

		if(buttonTimeVal >= 0)
		{
			//char stringBuffer[20];

			extern uint16_t anaB_samples;

			sprintf_P(stringBuffer,
					PSTR("buttonTime=%"PRIi32" sampleCount=%"PRIu16"\n\r"), 
						buttonTimeVal, anaB_samples);
			puat_sendStringBlocking(0, stringBuffer);
		}
	}
}

