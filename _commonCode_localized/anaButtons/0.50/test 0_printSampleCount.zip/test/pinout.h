#ifndef __PINOUT_H__
#define __PINOUT_H__

//This should be moved to the makefile...
//#define HEARTBEAT       PB6       //(MISO)
//#define HEARTBEATPIN    PINB
//#define HEARTCONNECTION LED_TIED_HIGH


//Using the programming-header for debugging uart...
//
//
// 1  GND
// 2  V+
// 3  SCK   PB7   Rx0   (puar)
// 4  MOSI  PB5   Tx0   (puat)
// 5  /RST
// 6  MISO  PB6   (Heart)

#define Rx0pin    PB7      //SCK
#define Rx0PORT   PORTB

//Making it more pin-compatible with sdramThing3.0...
#define Tx0pin		PD6	//PB5		//MOSI
#define Tx0PORT	PORTD	//PORTB


//These are no longer valid a/o anaDigi... and it's in the makefile anyhow
//AIN0 (+) = PB2 = Internal Bandgap
//AIN1 (-) = PB3 

//so far, ANABUTTONS_PIN must be the pin-name of the AIN it's connected to
// This must be the - input of the comparator. See anaButtons.c for a
// schematic example...
//On the 8515 this is PB3...
// Actually, these need to be in the makefile...
//#define ANABUTTONS_PIN PB3
//#define ANABUTTONS_PORT	PORTB



#endif

